# OB Awto Bezegleri — başlangıç Android projesi

## İçindekiler
- Android WebView kabuğu ve çevrimdışı çalışan mağaza arayüzü
- Ürün kataloğu, marka/model filtreleri, sepet, yerel sipariş kaydı
- Basit ürün ekleme/silme yönetim paneli
- Türkçe, Türkmençe ve İngilizce arayüz
- GitHub Actions ile APK derleme iş akışı

## Önemli sınırlar
Bu ilk sürüm bir prototiptir. Ürünler, sepet ve siparişler cihazın yerel depolamasında tutulur. Başka telefonlara senkronize olmaz; siparişler mağazaya gönderilmez. Yönetici paneli şifresizdir. Gerçek satışa geçmeden önce güvenli yönetici girişi, çevrimiçi veritabanı, sipariş bildirimi, ödeme ve gizlilik koşulları eklenmelidir. Ödeme bilgisi toplamaz.

## Telefonda APK oluşturma (bilgisayarsız yol)
1. GitHub hesabı aç veya hesabına giriş yap.
2. Bu ZIP dosyasını aç; içindeki dosyaları yeni bir GitHub deposuna yükle. `.github/workflows/build.yml` dosyasının da yüklendiğinden emin ol.
3. Depoda **Actions** sekmesine gir.
4. **Build Android APK** iş akışını seçip **Run workflow** düğmesine bas.
5. İşlem tamamlanınca çalıştırma sayfasındaki **Artifacts** bölümünden `OB-Awto-Bezegleri-APK` dosyasını indir.
6. ZIP içindeki `app-debug.apk` dosyasını telefona kur. Android sorarsa yalnızca bu dosya için tarayıcıya/dosya yöneticisine yükleme izni ver.

## Bilgisayarda Android Studio ile
Projeyi aç, Gradle senkronizasyonunu bekle ve `Build > Build APK(s)` seç. APK `app/build/outputs/apk/debug/` klasörüne çıkar.

## İlk açılış
Örnek ürünler gelir. Yönetici sekmesinden kendi ürünlerini ekleyebilirsin. Para birimi şimdilik USD'dir. Ürün görselleri ve gerçek mağaza bağlantısı sonraki aşamada eklenecek.
